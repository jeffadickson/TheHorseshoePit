$2 ~ /ava|bwk/
