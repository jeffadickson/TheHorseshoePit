{print NF,$0}
