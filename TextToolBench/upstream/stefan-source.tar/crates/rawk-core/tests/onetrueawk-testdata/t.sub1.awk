{sub(/.$/,"x"); print}
