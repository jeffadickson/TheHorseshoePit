/Asia/ || /Africa/
