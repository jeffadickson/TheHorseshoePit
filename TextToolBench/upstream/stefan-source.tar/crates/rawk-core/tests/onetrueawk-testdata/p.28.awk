{ print NR ":" $0 }
