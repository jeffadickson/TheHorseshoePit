{sub(/.$/,"&&"); print}
{sub(/.$/,"&\\&&"); print}
