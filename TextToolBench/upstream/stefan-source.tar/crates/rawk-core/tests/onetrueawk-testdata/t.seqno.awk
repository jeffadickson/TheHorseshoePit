{print NR, $0}
