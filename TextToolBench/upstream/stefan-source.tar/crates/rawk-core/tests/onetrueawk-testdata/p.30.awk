{ print length, $0 }
