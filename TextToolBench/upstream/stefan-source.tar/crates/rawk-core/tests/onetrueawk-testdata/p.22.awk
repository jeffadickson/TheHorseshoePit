$4 ~ /^(Asia|Europe)$/
