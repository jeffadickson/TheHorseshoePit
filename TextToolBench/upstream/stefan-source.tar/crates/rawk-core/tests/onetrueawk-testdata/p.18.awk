/(apple|cherry) (pie|tart)/
