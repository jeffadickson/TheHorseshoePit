{$1 = NR; print}
