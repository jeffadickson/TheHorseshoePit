{gsub(/[aeiou]/,"foo"); print}
