{ print $NF++; print $NF }
