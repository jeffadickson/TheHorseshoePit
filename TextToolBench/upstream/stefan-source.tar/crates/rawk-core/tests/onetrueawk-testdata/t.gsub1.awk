{gsub(/$/,"x"); print}
